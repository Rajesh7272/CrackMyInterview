# CrackMyInterview

A transparent interview-preparation companion with resume/JD context, question drafting, streamed AI responses, and a QR-linked mobile companion.

## Requirements
- Python 3.10+
- Node.js 18+
- A Groq API key (optional; without it, the app returns a clearly-labelled local coaching template)

## Run the backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Add GROQ_API_KEY to .env for AI-generated responses
uvicorn app.main:app --reload --port 8000
```

## Run the web app
In another terminal:
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173. The frontend expects the API at http://localhost:8000.

### Phone on the same Wi-Fi
For a phone to connect, run Vite and FastAPI bound to `0.0.0.0` (the commands above do this), then create `frontend/.env` with:
```bash
VITE_API_URL=http://YOUR_COMPUTER_LAN_IP:8000
```
Restart Vite, open the frontend on your computer using `http://YOUR_COMPUTER_LAN_IP:5173`, and scan the QR code. Allow ports 5173 and 8000 through your local firewall if prompted.

## Optional desktop shell
```bash
cd desktop
npm install
npm start
```
The Electron window opens the local web app. Start the backend and frontend first.

## Features
- Upload PDF, DOCX, TXT, or Markdown resume/JD files.
- Add a role and interview question; receive a concise answer streamed over WebSocket.
- Browser speech recognition where supported (user starts/stops it visibly).
- Create a session QR code and connect a phone using `/mobile?session=...`.
- Session-scoped WebSocket updates between desktop and phone.

## Safety and privacy
This is a visible interview-preparation/coaching tool. It does not hide windows, evade screen-sharing or monitoring controls, or capture system audio covertly. Speech input is initiated visibly by the user. Uploaded documents and session data are held in server memory and are not persisted to disk by this starter app. Do not upload confidential employer/customer information.
