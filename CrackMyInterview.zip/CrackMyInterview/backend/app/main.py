import json
from fastapi import FastAPI, UploadFile, File, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from .config import FRONTEND_ORIGIN
from .session_store import SESSIONS, create_session, get_session
from .parsing import extract_text
from .llm import stream_answer

app = FastAPI(title="CrackMyInterview API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=[FRONTEND_ORIGIN, "http://127.0.0.1:5173"],
                   allow_credentials=True, allow_methods=["*"], allow_headers=["*"], allow_origin_regex=r"https?://(localhost|127\\.0\\.0\\.1|\\d{1,3}(\\.\\d{1,3}){3})(:\\d+)?")

class AskBody(BaseModel):
    question: str
    role: str = ""

class RoleBody(BaseModel):
    role: str = ""

@app.get("/health")
async def health():
    return {"status": "ok", "service": "CrackMyInterview"}

@app.post("/api/sessions")
async def new_session():
    token = create_session()
    return {"token": token}

@app.get("/api/sessions/{token}")
async def session_info(token: str):
    s = get_session(token)
    if not s:
        raise HTTPException(404, "Session not found or expired")
    return {"role": s["role"], "has_resume": bool(s["resume"]),
            "has_job_description": bool(s["job_description"]), "history": s["history"][-12:]}

@app.post("/api/sessions/{token}/upload/{kind}")
async def upload(token: str, kind: str, file: UploadFile = File(...)):
    s = get_session(token)
    if not s:
        raise HTTPException(404, "Session not found or expired")
    if kind not in {"resume", "job-description"}:
        raise HTTPException(400, "kind must be resume or job-description")
    data = await file.read()
    if len(data) > 5 * 1024 * 1024:
        raise HTTPException(413, "File limit is 5 MB")
    try:
        content = extract_text(file.filename or "upload.txt", data)
    except Exception as e:
        raise HTTPException(400, str(e))
    s["resume" if kind == "resume" else "job_description"] = content[:30000]
    return {"ok": True, "characters": len(content)}

@app.post("/api/sessions/{token}/role")
async def set_role(token: str, body: RoleBody):
    s = get_session(token)
    if not s:
        raise HTTPException(404, "Session not found or expired")
    s["role"] = body.role[:200]
    return {"ok": True}

@app.websocket("/ws/{token}")
async def websocket_endpoint(ws: WebSocket, token: str):
    s = get_session(token)
    if not s:
        await ws.close(code=4404)
        return
    await ws.accept()
    s["clients"].add(ws)
    try:
        await ws.send_json({"type": "connected", "message": "Session connected"})
        while True:
            message = await ws.receive_json()
            if message.get("type") == "answer_now":
                question = str(message.get("question", "")).strip()[:2000]
                if not question:
                    continue
                await broadcast(s, {"type": "question", "question": question})
                answer = ""
                try:
                    async for chunk in stream_answer(question, s["role"], s["resume"], s["job_description"]):
                        answer += chunk
                        await broadcast(s, {"type": "answer_chunk", "chunk": chunk})
                    s["history"].append({"question": question, "answer": answer})
                    await broadcast(s, {"type": "answer_done"})
                except Exception as e:
                    await broadcast(s, {"type": "error", "message": f"AI request failed: {str(e)[:240]}"})
            elif message.get("type") == "ping":
                await ws.send_json({"type": "pong"})
    except WebSocketDisconnect:
        pass
    finally:
        s["clients"].discard(ws)

async def broadcast(session, payload):
    stale = []
    for client in list(session["clients"]):
        try:
            await client.send_text(json.dumps(payload))
        except Exception:
            stale.append(client)
    for client in stale:
        session["clients"].discard(client)
