import json
import httpx
from .config import GROQ_API_KEY, GROQ_MODEL

def build_prompt(question: str, role: str, resume: str, jd: str) -> str:
    return f'''You are an interview preparation coach. Draft a truthful, natural, concise first-person answer.
Never invent employers, tools, metrics, responsibilities, certifications, or outcomes. If context is missing, say what should be clarified rather than fabricating.
Target role: {role or "Not specified"}
Resume context:
{resume[:12000] or "Not provided"}
Job description:
{jd[:8000] or "Not provided"}
Question: {question}
Answer in a spoken, confident style. Use STAR only when appropriate.'''

async def stream_answer(question: str, role: str, resume: str, jd: str):
    if not GROQ_API_KEY:
        fallback = (
            "Add a Groq API key in backend/.env to enable AI-generated answers.\\n\\n"
            "Preparation outline:\\n"
            "1. Answer the question directly in the first sentence.\\n"
            "2. Use one relevant example from your real experience.\\n"
            "3. Explain your actions and the outcome without inventing metrics.\\n"
            "4. Connect the example to the target role."
        )
        for word in fallback.split(" "):
            yield word + " "
        return

    payload = {
        "model": GROQ_MODEL,
        "messages": [{"role": "user", "content": build_prompt(question, role, resume, jd)}],
        "temperature": 0.35,
        "max_tokens": 900,
        "stream": True,
    }
    headers = {"Authorization": f"Bearer {GROQ_API_KEY}", "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=90) as client:
        async with client.stream("POST", "https://api.groq.com/openai/v1/chat/completions",
                                 headers=headers, json=payload) as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                if not line.startswith("data: "):
                    continue
                raw = line[6:]
                if raw == "[DONE]":
                    break
                try:
                    chunk = json.loads(raw)["choices"][0]["delta"].get("content", "")
                    if chunk:
                        yield chunk
                except (ValueError, KeyError, IndexError):
                    continue
