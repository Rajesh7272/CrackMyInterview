from datetime import datetime, timedelta, timezone
from secrets import token_urlsafe
from typing import Any

SESSIONS: dict[str, dict[str, Any]] = {}

def create_session():
    token = token_urlsafe(18)
    SESSIONS[token] = {
        "created_at": datetime.now(timezone.utc),
        "expires_at": datetime.now(timezone.utc) + timedelta(hours=8),
        "resume": "",
        "job_description": "",
        "role": "",
        "history": [],
        "clients": set(),
    }
    return token

def get_session(token: str):
    item = SESSIONS.get(token)
    if not item:
        return None
    if item["expires_at"] < datetime.now(timezone.utc):
        SESSIONS.pop(token, None)
        return None
    return item
