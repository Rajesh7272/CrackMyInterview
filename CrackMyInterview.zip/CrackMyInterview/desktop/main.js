const {app,BrowserWindow,shell}=require('electron');
const path=require('node:path');
function createWindow(){
 const win=new BrowserWindow({width:1440,height:940,minWidth:900,minHeight:650,
  title:'CrackMyInterview',backgroundColor:'#090b12',
  webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false}});
 win.loadURL(process.env.APP_URL||'http://localhost:5173');
 win.webContents.setWindowOpenHandler(({url})=>{shell.openExternal(url);return {action:'deny'}});
}
app.whenReady().then(()=>{createWindow();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow()})});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});
